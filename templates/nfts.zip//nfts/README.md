# NFTs

* Num: Issuing the first ten natural numbers as collectible NFT's.
* Marketplace: An opensea-like marketplace built with shared objects.
* geniteam: NFTs representing collectible monsters and cosmetics used in a farming game.
* Auction: example implementation of an [English auction](https://en.wikipedia.org/wiki/English_auction) using single-owner objects only.
* SharedAuction: example implementation of an [English auction](https://en.wikipedia.org/wiki/English_auction) using shared objects.
* ImageNFT: an NFT wrapping a URL pointing to an image stored off-chain (coming in future).
