# Umi AMM v1.2

This repository contains the core smart contracts for the Umi V1 Protocol.

