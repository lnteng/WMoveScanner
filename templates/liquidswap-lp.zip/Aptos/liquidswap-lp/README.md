# Liquidswap LP

Liquidity Pool Coin template and test coins for [Liquidswap](https://liquidswap.pontem.network).

See built binary in [binaries](binaries) folder.

## Build

    aptos move compile
