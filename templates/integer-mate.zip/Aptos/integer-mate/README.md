# IntegerMate

A Libary of move module provides signed integer and some integer math functions.



