# Sidewinder - simple testing and utils for your move contracts using python

## what does sidewinder do?

Sidewinder allows you to compile and run move contracts and tests
