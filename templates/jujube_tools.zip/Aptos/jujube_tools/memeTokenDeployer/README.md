# meme_contract
meme deploy
